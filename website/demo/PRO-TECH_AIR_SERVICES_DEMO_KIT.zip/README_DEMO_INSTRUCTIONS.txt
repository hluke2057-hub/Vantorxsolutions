================================================================================
PRO-TECH AIR SERVICES LLC — DEMO PRESENTATION KIT
================================================================================
Contents of this Kit:
1. PRO-TECH_AIR_SERVICES_DEMO_PRESENTATION.pdf
   - High-resolution, 16:9 widescreen presentation deck (8 slides).
   - Perfect for opening in Adobe Acrobat, Edge, Chrome, or Apple Preview to present
     via Zoom, Google Meet, or in person on a tablet or laptop.

2. PRO-TECH_OFFLINE_PRESENTATION.html
   - Fully standalone offline interactive deck.
   - Double-click to open in any web browser without needing internet.
   - Use Left / Right arrow keys to navigate slides.

3. PRO-TECH_DEMO_WORD_FOR_WORD_SCRIPT.txt
   - Word-for-word spoken script for each of the 8 slides.

4. PRO-TECH_OBJECTION_HANDLING_BATTLE_CARD.txt
   - Word-for-word answers to every objection Carlin might raise.

Live Interactive Test Line:
- Phone: (561) 813-8602
- Have Carlin dial this on speaker during Slide 5!
================================================================================
