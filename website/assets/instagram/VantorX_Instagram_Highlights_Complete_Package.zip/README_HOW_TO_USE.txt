================================================================================
VANTORX™ INSTAGRAM HIGHLIGHTS & BRAND ASSET MASTER PACKAGE
================================================================================

Everything you need to set up a world-class, conversion-focused Instagram profile
for VantorX Solutions.

PACKAGE CONTENTS:
--------------------------------------------------------------------------------
📁 01_CLEAN_HIGHLIGHT_COVERS_8_PICTURES (1080 x 1080 Circle-Safe Covers)
   - cover_01_ava_ai.png        -> AVA Voice AI highlight
   - cover_02_leadflow.png      -> 90-Sec LeadFlow highlight
   - cover_03_websites.png      -> Custom Contractor Websites highlight
   - cover_04_aeo_rank.png      -> AEO / AI Search Ranking highlight
   - cover_05_accelerate.png    -> Accelerate Package highlight
   - cover_06_results.png       -> Live Client Proof & Results highlight
   - cover_07_live_demo.png     -> Voice Demo & Phone Recordings highlight
   - cover_08_scale_fleet.png   -> Scale Enterprise Package highlight

📁 02_CORE_STORY_HIGHLIGHTS_15_PICTURES (1080 x 1920 HD Vertical Stories)
   Organized across 5 highlight categories (3 sequential slides each):
   1. 01_Packages_Basic_Accelerate_Scale (Basic $997, Accelerate $1,497, Scale $4,997)
   2. 02_AVA_Voice_AI_Receptionist (Missed call bleed, 24/7 AI dispatch, Live demo)
   3. 03_Custom_Contractor_Website (Why 2012 sites bleed sales, Sub-second UX, $142K proof)
   4. 04_AEO_Search_Engine_Optimization (What is AEO, Perplexity/ChatGPT crawl, Domination)
   5. 05_LeadFlow_90_Second_Speed_To_Lead (The 90s rule, SMS dispatch, 0 lost leads)

📁 03_ALL_PRODUCTS_CAROUSELS_21_PICTURES (1080 x 1080 Square Post Slides)
   3 sequential carousel slides for each of VantorX's 7 core products.

📁 04_BRAND_LOGOS_AND_PFPS
   - vantorx_logo_pfp.png       -> High-res transparent PNG logo
   - vantorx_logo_3d_pfp.jpg    -> Hyper-detailed obsidian & amber 3D logo

HOW TO SET UP YOUR INSTAGRAM HIGHLIGHTS (STEP-BY-STEP):
--------------------------------------------------------------------------------
1. POST STORIES:
   Post the 3 vertical story graphics from a category folder to your Instagram Story.

2. ADD TO HIGHLIGHT:
   - View your posted story, tap "Highlight" at the bottom right.
   - Choose "New Highlight" and give it a short, punchy name (e.g. "AVA AI", "Packages").

3. SET THE CLEAN COVER:
   - Tap and hold your new Highlight on your Instagram profile page.
   - Select "Edit Highlight" -> "Edit Cover".
   - Tap the gallery icon and select the corresponding 1080x1080 cover from
     the "01_CLEAN_HIGHLIGHT_COVERS_8_PICTURES" folder.
   - Notice how perfectly the glowing amber icon and typography are centered
     inside Instagram's circular crop without touching the edges!

Need web preview or to download individual slides?
Visit: https://www.vantorxsolutions.com/instagram-package/
